package com.example.dice_rolling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
