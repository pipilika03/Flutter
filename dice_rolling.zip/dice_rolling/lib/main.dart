import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(DiceRollingApp());
}

class DiceRollingApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dice Rolling App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: DiceRollingPage(),
    );
  }
}

class DiceRollingPage extends StatefulWidget {
  @override
  _DiceRollingPageState createState() => _DiceRollingPageState();
}

class _DiceRollingPageState extends State<DiceRollingPage> {
  int dice = 1;

  void rollDice() {
    setState(() {
      dice = Random().nextInt(6) +
          1; // Generate a random number between 1 and 6 for the dice
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 165, 22, 11),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _buildDice(dice),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: rollDice,
              child: Text(
                'Rolling',
                style: TextStyle(fontSize: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDice(int diceNumber) {
    return Image.asset(
      'images/dice$diceNumber.png',
      width: 100,
      height: 100,
    );
  }
}
